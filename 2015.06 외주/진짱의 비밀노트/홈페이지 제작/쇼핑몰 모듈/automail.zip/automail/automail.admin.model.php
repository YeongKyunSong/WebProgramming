<?php
/**
 * vi:set sw=4 ts=4 noexpandtab fileencoding=utf8:
 * @class  automailAdminModel
 * @author NURIGO(contact@coolsms.co.kr)
 * @brief  automailAdminModel
 */
class automailAdminModel extends automail 
{
}
/* End of file automail.admin.model.php */
/* Location: ./modules/automail/automail.admin.model.php */
