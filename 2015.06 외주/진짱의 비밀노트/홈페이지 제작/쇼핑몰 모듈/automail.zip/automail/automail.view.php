<?php
/**
 * vi:set sw=4 ts=4 noexpandtab fileencoding=utf8:
 * @class  automailView
 * @author NURIGO(contact@nurigo.net)
 * @brief  automailView
 */
class automailView extends automail 
{
	function init() 
	{
	}
}
/* End of file automail.view.php */
/* Location: ./modules/automail/automail.view.php */
