<?php
/**
 * vi:set sw=4 ts=4 noexpandtab fileencoding=utf-8:
 * @class  licenseView
 * @author NURIGO(contact@nurigo.net)
 * @brief  licenseView
 */
class licenseView extends license
{
}
/* End of file license.view.php */
/* Location: ./modules/license/license.view.php */
