<?php
/**
 * vi:set sw=4 ts=4 noexpandtab fileencoding=utf-8:
 * @class  licenseAdminModel
 * @author NURIGO(contact@nurigo.net)
 * @brief  licenseAdminModel
 */ 
class licenseAdminModel extends license
{
}
/* End of file license.admin.model.php */
/* Location: ./modules/license/license.admin.model.php */
