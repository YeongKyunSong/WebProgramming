<?php
/**
 * vi:set sw=4 ts=4 noexpandtab fileencoding=utf-8:
 * @class  licenseController
 * @author NURIGO(contact@nurigo.net)
 * @brief  licenseController
 */
class licenseController extends license
{
}
/* End of file license.controller.php */
/* Location: ./modules/license/license.controller.php */
