<?php
/**
 * vi:set ts=4 sw=4 noexpandtab fileencoding=utf-8:
 * @class  nstoreAPI
 * @author diver(diver@coolsms.co.kr)
 * @brief  nstoreAPI
 **/
class nstoreAPI extends nstore
{
}
/* End of file nstore.api.php */
/* Location: ./modules/nstore/nstore.api.php */
