jQuery(document).ready(function($){
	$('#delete_button').click(function(){
		console.log(checkbox);
	});
});
