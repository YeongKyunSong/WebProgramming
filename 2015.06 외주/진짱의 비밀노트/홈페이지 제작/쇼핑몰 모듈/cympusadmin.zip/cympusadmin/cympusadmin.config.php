<?php
define('_CYMPUSADMIN_MENU_', 'menu.xml');
define('_CYMPUSADMIN_INDEX_', 'dashboard');
define('_CYMPUSADMIN_LAYOUT_', 'layout.html');
define('_CYMPUSADMIN_FUNCTION_', 'functions.php');
