<?php
/**
 * vi:set ts=4 sw=4 noexpandtab fileencoding=utf-8:
 * @class  nstore_digitalAPI
 * @author NURIGO(contact@nurigo.net)
 * @brief  nstore_digitalAPI
 **/
class nstore_digitalAPI extends nstore_digital 
{
}
